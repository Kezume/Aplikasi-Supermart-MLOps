/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  emoji: string;
  price: number;
  category: string;
  isBestSeller: boolean;
  rank?: number;
}

export interface AssociationRule {
  if_buy: string[];
  recommend: string[];
  confidence: number; // e.g. 0.605 for 60.5%
  lift: number; // e.g. 2.70
  support: number; // e.g. 0.048 for 4.8%
}

export const PRODUCTS: Product[] = [
  { id: "cereal", name: "Cereal", emoji: "🥣", price: 24500, category: "Sarapan", isBestSeller: true, rank: 1 },
  { id: "ice_cream", name: "Ice Cream", emoji: "🍦", price: 32000, category: "Makanan Beku", isBestSeller: true, rank: 2 },
  { id: "chicken", name: "Chicken", emoji: "🍗", price: 45000, category: "Daging", isBestSeller: true, rank: 3 },
  { id: "soda", name: "Soda", emoji: "🥫", price: 8000, category: "Minuman", isBestSeller: true, rank: 4 },
  { id: "juice", name: "Juice", emoji: "🍹", price: 15000, category: "Minuman", isBestSeller: true, rank: 5 },
  { id: "cheese", name: "Cheese", emoji: "🧀", price: 22000, category: "Olahan Susu", isBestSeller: true, rank: 6 },
  { id: "soap", name: "Soap", emoji: "🧼", price: 6000, category: "Perawatan Tubuh", isBestSeller: true, rank: 7 },
  { id: "beans", name: "Beans", emoji: "🫘", price: 12000, category: "Biji-bijian", isBestSeller: true, rank: 8 },
  { id: "orange", name: "Orange", emoji: "🍊", price: 28000, category: "Buah-buahan", isBestSeller: true, rank: 9 },
  { id: "sausage", name: "Sausage", emoji: "🌭", price: 35000, category: "Daging", isBestSeller: true, rank: 10 },

  // Non-bestseller products (30 items)
  { id: "apple", name: "Apple", emoji: "🍎", price: 30000, category: "Buah-buahan", isBestSeller: false },
  { id: "banana", name: "Banana", emoji: "🍌", price: 16000, category: "Buah-buahan", isBestSeller: false },
  { id: "beans_chickpeas", name: "Chickpeas", emoji: "🫛", price: 14500, category: "Biji-bijian", isBestSeller: false },
  { id: "bread", name: "Bread", emoji: "🍞", price: 14000, category: "Roti", isBestSeller: false },
  { id: "butter", name: "Butter", emoji: "🧈", price: 19500, category: "Olahan Susu", isBestSeller: false },
  { id: "chips", name: "Chips", emoji: "🍿", price: 9500, category: "Camilan", isBestSeller: false },
  { id: "chocolate", name: "Chocolate", emoji: "🍫", price: 15000, category: "Camilan", isBestSeller: false },
  { id: "cola", name: "Cola", emoji: "🥤", price: 8500, category: "Minuman", isBestSeller: false },
  { id: "cookie", name: "Cookie", emoji: "🍪", price: 12500, category: "Camilan", isBestSeller: false },
  { id: "cracker", name: "Cracker", emoji: "🫓", price: 10000, category: "Camilan", isBestSeller: false },
  { id: "cucumber", name: "Cucumber", emoji: "🥒", price: 7000, category: "Sayuran", isBestSeller: false },
  { id: "detergent", name: "Detergent", emoji: "🧴", price: 26000, category: "Kebutuhan Rumah", isBestSeller: false },
  { id: "dish_sponge", name: "Dish Sponge", emoji: "𧽏", price: 4500, category: "Kebutuhan Rumah", isBestSeller: false }, // Using common sponge code or plain emoji
  { id: "dumpling", name: "Dumpling", emoji: "🥟", price: 28000, category: "Makanan Beku", isBestSeller: false },
  { id: "egg", name: "Egg", emoji: "🥚", price: 21000, category: "Olahan Susu", isBestSeller: false },
  { id: "fish", name: "Fish", emoji: "🐟", price: 38000, category: "Daging", isBestSeller: false },
  { id: "flatbread_meat", name: "Flatbread With Meat", emoji: "🥙", price: 25000, category: "Roti", isBestSeller: false },
  { id: "honey", name: "Honey", emoji: "🍯", price: 48000, category: "Sarapan", isBestSeller: false },
  { id: "lentil", name: "Lentil", emoji: "🫘", price: 13000, category: "Biji-bijian", isBestSeller: false },
  { id: "milk", name: "Milk", emoji: "🥛", price: 18000, category: "Olahan Susu", isBestSeller: false },
  { id: "minced_meat", name: "Minced Meat", emoji: "🥩", price: 52000, category: "Daging", isBestSeller: false },
  { id: "onion", name: "Onion", emoji: "🧅", price: 9000, category: "Sayuran", isBestSeller: false },
  { id: "pizza", name: "Pizza", emoji: "🍕", price: 65000, category: "Makanan Beku", isBestSeller: false },
  { id: "potato", name: "Potato", emoji: "🥔", price: 11000, category: "Sayuran", isBestSeller: false },
  { id: "rice", name: "Rice", emoji: "🍚", price: 14000, category: "Biji-bijian", isBestSeller: false },
  { id: "shampoo", name: "Shampoo", emoji: "🧴", price: 24000, category: "Perawatan Tubuh", isBestSeller: false },
  { id: "strawberry", name: "Strawberry", emoji: "🍓", price: 35000, category: "Buah-buahan", isBestSeller: false },
  { id: "tomato", name: "Tomato", emoji: "🍅", price: 12000, category: "Sayuran", isBestSeller: false },
  { id: "water", name: "Water", emoji: "💧", price: 5000, category: "Minuman", isBestSeller: false },
  { id: "yogurt", name: "Yogurt", emoji: "🥛", price: 10500, category: "Olahan Susu", isBestSeller: false },
];

export const RULES: AssociationRule[] = [
  // Top Strong Rules (Cookie, Banana, Bread, Mild & Cereal relations)
  { if_buy: ["Cookie", "Cereal"], recommend: ["Milk"], confidence: 0.605, lift: 2.70, support: 0.048 },
  { if_buy: ["Banana", "Cereal"], recommend: ["Milk"], confidence: 0.431, lift: 2.65, support: 0.039 },
  { if_buy: ["Milk", "Bread"], recommend: ["Cereal"], confidence: 0.605, lift: 2.60, support: 0.052 },
  { if_buy: ["Milk"], recommend: ["Cereal"], confidence: 0.584, lift: 2.51, support: 0.085 },
  { if_buy: ["Cereal"], recommend: ["Milk"], confidence: 0.409, lift: 2.51, support: 0.085 },
  { if_buy: ["Chocolate", "Cereal"], recommend: ["Milk"], confidence: 0.612, lift: 2.68, support: 0.035 },
  { if_buy: ["Yogurt", "Cereal"], recommend: ["Milk"], confidence: 0.620, lift: 2.68, support: 0.041 },
  { if_buy: ["Strawberry", "Cereal"], recommend: ["Milk"], confidence: 0.590, lift: 2.58, support: 0.032 },
  { if_buy: ["Honey", "Cereal"], recommend: ["Milk"], confidence: 0.580, lift: 2.53, support: 0.025 },
  { if_buy: ["Milk", "Egg"], recommend: ["Cereal"], confidence: 0.572, lift: 2.50, support: 0.046 },
  { if_buy: ["Milk", "Banana"], recommend: ["Cereal"], confidence: 0.598, lift: 2.61, support: 0.040 },
  { if_buy: ["Milk", "Cookie"], recommend: ["Cereal"], confidence: 0.614, lift: 2.68, support: 0.043 },
  { if_buy: ["Milk", "Yogurt"], recommend: ["Cereal"], confidence: 0.565, lift: 2.47, support: 0.038 },
  { if_buy: ["Milk", "Butter"], recommend: ["Cereal"], confidence: 0.542, lift: 2.37, support: 0.035 },
  { if_buy: ["Milk", "Strawberry"], recommend: ["Cereal"], confidence: 0.587, lift: 2.56, support: 0.031 },
  { if_buy: ["Cereal", "Butter"], recommend: ["Milk"], confidence: 0.530, lift: 2.31, support: 0.034 },
  { if_buy: ["Cereal", "Bread"], recommend: ["Milk"], confidence: 0.554, lift: 2.42, support: 0.048 },
  { if_buy: ["Cereal", "Egg"], recommend: ["Milk"], confidence: 0.528, lift: 2.31, support: 0.042 },
  { if_buy: ["Cereal", "Orange"], recommend: ["Milk"], confidence: 0.515, lift: 2.25, support: 0.030 },
  { if_buy: ["Cereal", "Apple"], recommend: ["Milk"], confidence: 0.508, lift: 2.22, support: 0.028 },
  { if_buy: ["Cereal", "Potato"], recommend: ["Milk"], confidence: 0.485, lift: 2.12, support: 0.024 },
  { if_buy: ["Cereal", "Chips"], recommend: ["Milk"], confidence: 0.490, lift: 2.14, support: 0.026 },
  { if_buy: ["Cereal", "Tomato"], recommend: ["Milk"], confidence: 0.472, lift: 2.06, support: 0.021 },
  { if_buy: ["Cereal", "Cheese"], recommend: ["Milk"], confidence: 0.561, lift: 2.45, support: 0.049 },
  { if_buy: ["Milk", "Cheese"], recommend: ["Cereal"], confidence: 0.552, lift: 2.41, support: 0.049 },
  { if_buy: ["Cereal", "Soap"], recommend: ["Milk"], confidence: 0.460, lift: 2.01, support: 0.018 },
  { if_buy: ["Cereal", "Sausage"], recommend: ["Milk"], confidence: 0.535, lift: 2.34, support: 0.031 },
  { if_buy: ["Milk", "Sausage"], recommend: ["Cereal"], confidence: 0.521, lift: 2.28, support: 0.031 },
  { if_buy: ["Cereal", "Ice Cream"], recommend: ["Milk"], confidence: 0.570, lift: 2.49, support: 0.036 },
  { if_buy: ["Milk", "Ice Cream"], recommend: ["Cereal"], confidence: 0.548, lift: 2.39, support: 0.036 },
  { if_buy: ["Cereal", "Chicken"], recommend: ["Milk"], confidence: 0.505, lift: 2.21, support: 0.029 },
  { if_buy: ["Milk", "Chicken"], recommend: ["Cereal"], confidence: 0.482, lift: 2.10, support: 0.029 },
  { if_buy: ["Cereal", "Juice"], recommend: ["Milk"], confidence: 0.520, lift: 2.27, support: 0.033 },
  { if_buy: ["Milk", "Juice"], recommend: ["Cereal"], confidence: 0.495, lift: 2.16, support: 0.033 },
  { if_buy: ["Cereal", "Soda"], recommend: ["Milk"], confidence: 0.455, lift: 1.99, support: 0.025 },
  { if_buy: ["Cereal", "Water"], recommend: ["Milk"], confidence: 0.440, lift: 1.92, support: 0.022 },
  { if_buy: ["Cereal", "Rice"], recommend: ["Milk"], confidence: 0.510, lift: 2.23, support: 0.028 },
  { if_buy: ["Milk", "Rice"], recommend: ["Cereal"], confidence: 0.490, lift: 2.14, support: 0.028 },
  { if_buy: ["Cereal", "Beans"], recommend: ["Milk"], confidence: 0.528, lift: 2.31, support: 0.035 },
  { if_buy: ["Milk", "Beans"], recommend: ["Cereal"], confidence: 0.502, lift: 2.19, support: 0.035 },
  { if_buy: ["Milk", "Apple"], recommend: ["Cereal"], confidence: 0.480, lift: 2.10, support: 0.026 },
  { if_buy: ["Milk", "Potato"], recommend: ["Cereal"], confidence: 0.465, lift: 2.03, support: 0.023 },
  { if_buy: ["Milk", "Chips"], recommend: ["Cereal"], confidence: 0.478, lift: 2.09, support: 0.025 },
  { if_buy: ["Milk", "Chocolate"], recommend: ["Cereal"], confidence: 0.530, lift: 2.31, support: 0.030 },
  { if_buy: ["Milk", "Honey"], recommend: ["Cereal"], confidence: 0.556, lift: 2.43, support: 0.024 },

  // Antecedents triggering Milk or Cereal
  { if_buy: ["Bread"], recommend: ["Milk"], confidence: 0.385, lift: 1.68, support: 0.072 },
  { if_buy: ["Bread"], recommend: ["Cereal"], confidence: 0.320, lift: 1.40, support: 0.059 },
  { if_buy: ["Egg"], recommend: ["Milk"], confidence: 0.420, lift: 1.83, support: 0.068 },
  { if_buy: ["Egg"], recommend: ["Cereal"], confidence: 0.355, lift: 1.55, support: 0.057 },
  { if_buy: ["Yogurt"], recommend: ["Milk"], confidence: 0.480, lift: 2.10, support: 0.055 },
  { if_buy: ["Yogurt"], recommend: ["Cereal"], confidence: 0.415, lift: 1.81, support: 0.048 },
  { if_buy: ["Banana"], recommend: ["Milk"], confidence: 0.395, lift: 1.73, support: 0.051 },
  { if_buy: ["Banana"], recommend: ["Cereal"], confidence: 0.340, lift: 1.48, support: 0.044 },
  { if_buy: ["Cookie"], recommend: ["Milk"], confidence: 0.425, lift: 1.86, support: 0.047 },
  { if_buy: ["Cookie"], recommend: ["Cereal"], confidence: 0.368, lift: 1.61, support: 0.041 },
  { if_buy: ["Strawberry"], recommend: ["Milk"], confidence: 0.442, lift: 1.93, support: 0.038 },
  { if_buy: ["Strawberry"], recommend: ["Cereal"], confidence: 0.375, lift: 1.64, support: 0.032 },
  { if_buy: ["Butter"], recommend: ["Milk"], confidence: 0.405, lift: 1.77, support: 0.045 },
  { if_buy: ["Butter"], recommend: ["Cereal"], confidence: 0.338, lift: 1.48, support: 0.038 },
  { if_buy: ["Cheese"], recommend: ["Milk"], confidence: 0.450, lift: 1.97, support: 0.061 },
  { if_buy: ["Cheese"], recommend: ["Cereal"], confidence: 0.392, lift: 1.71, support: 0.053 },
  { if_buy: ["Sausage"], recommend: ["Milk"], confidence: 0.410, lift: 1.79, support: 0.042 },
  { if_buy: ["Sausage"], recommend: ["Cereal"], confidence: 0.355, lift: 1.55, support: 0.036 },
  { if_buy: ["Ice Cream"], recommend: ["Milk"], confidence: 0.435, lift: 1.90, support: 0.048 },
  { if_buy: ["Ice Cream"], recommend: ["Cereal"], confidence: 0.370, lift: 1.62, support: 0.041 },
  { if_buy: ["Juice"], recommend: ["Milk"], confidence: 0.390, lift: 1.70, support: 0.045 },
  { if_buy: ["Juice"], recommend: ["Cereal"], confidence: 0.332, lift: 1.45, support: 0.038 },
  { if_buy: ["Beans"], recommend: ["Milk"], confidence: 0.408, lift: 1.78, support: 0.048 },
  { if_buy: ["Beans"], recommend: ["Cereal"], confidence: 0.345, lift: 1.51, support: 0.041 },
  { if_buy: ["Chocolate"], recommend: ["Milk"], confidence: 0.412, lift: 1.80, support: 0.037 },
  { if_buy: ["Chocolate"], recommend: ["Cereal"], confidence: 0.350, lift: 1.53, support: 0.031 },
  { if_buy: ["Honey"], recommend: ["Milk"], confidence: 0.465, lift: 2.03, support: 0.028 },
  { if_buy: ["Honey"], recommend: ["Cereal"], confidence: 0.402, lift: 1.76, support: 0.024 },
  { if_buy: ["Orange"], recommend: ["Milk"], confidence: 0.385, lift: 1.68, support: 0.038 },
  { if_buy: ["Orange"], recommend: ["Cereal"], confidence: 0.318, lift: 1.39, support: 0.031 },
  { if_buy: ["Apple"], recommend: ["Milk"], confidence: 0.372, lift: 1.63, support: 0.034 },
  { if_buy: ["Apple"], recommend: ["Cereal"], confidence: 0.305, lift: 1.33, support: 0.028 },

  // A special reverse recommendation
  { if_buy: ["Cereal", "Milk"], recommend: ["Yogurt"], confidence: 0.425, lift: 2.15, support: 0.042 },
];
