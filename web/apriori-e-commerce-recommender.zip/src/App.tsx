/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from "react";
import { ShoppingCart, Database, Library, FileText, Sparkles, RefreshCw, Layers, CheckCircle2 } from "lucide-react";
import { PRODUCTS, Product } from "./data";
import ProductGrid from "./components/ProductGrid";
import CartView from "./components/CartView";
import RulesTable from "./components/RulesTable";

interface CartItem {
  product: Product;
  quantity: number;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<"toko" | "keranjang" | "rules">("toko");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  // Load cart from localStorage on init
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem("apriori_cart");
      if (savedCart) {
        setCart(JSON.parse(savedCart));
      }
    } catch (e) {
      console.error("Failed to parse cart from localStorage", e);
    }
  }, []);

  // Save cart to localStorage on state changes
  const saveCart = (newCart: CartItem[]) => {
    setCart(newCart);
    try {
      localStorage.setItem("apriori_cart", JSON.stringify(newCart));
    } catch (e) {
      console.error("Failed to save cart to localStorage", e);
    }
  };

  // Helper dictionary count of items in cart (for catalog badging)
  const cartItemsCount = useMemo(() => {
    const counts: { [key: string]: number } = {};
    cart.forEach((item) => {
      counts[item.product.name] = item.quantity;
    });
    return counts;
  }, [cart]);

  const handleAddToCart = (product: Product) => {
    const existingIndex = cart.findIndex((item) => item.product.name === product.name);
    let updatedCart = [...cart];

    if (existingIndex > -1) {
      updatedCart[existingIndex].quantity += 1;
    } else {
      updatedCart.push({ product, quantity: 1 });
    }

    saveCart(updatedCart);
    triggerToast(`Ditambahkan ke keranjang: ${product.emoji} ${product.name}`);
  };

  const handleUpdateQuantity = (productName: string, delta: number) => {
    const existingIndex = cart.findIndex((item) => item.product.name === productName);
    if (existingIndex === -1) return;

    let updatedCart = [...cart];
    const newQty = updatedCart[existingIndex].quantity + delta;

    if (newQty <= 0) {
      updatedCart.splice(existingIndex, 1);
    } else {
      updatedCart[existingIndex].quantity = newQty;
    }

    saveCart(updatedCart);
  };

  const handleRemoveItem = (productName: string) => {
    const updatedCart = cart.filter((item) => item.product.name !== productName);
    saveCart(updatedCart);
  };

  const handleClearCart = () => {
    saveCart([]);
    triggerToast("Keranjang berhasil dikosongkan");
  };

  const triggerToast = (message: string) => {
    setToastMessage(message);
    setShowToast(true);
  };

  // Clear toast after timeout
  useEffect(() => {
    if (showToast) {
      const timer = setTimeout(() => setShowToast(false), 2500);
      return () => clearTimeout(timer);
    }
  }, [showToast]);

  const totalCartCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col justify-between selection:bg-indigo-600/30 selection:text-indigo-200">
      
      {/* Header and Academic Metadata Branding */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 sticky top-0 z-50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 md:h-11 md:w-11 rounded-xl bg-indigo-600/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Database className="h-5.5 w-5.5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base md:text-lg font-black text-white tracking-tight">
                  APRIORI RECOMMENDER
                </h1>
                <span className="text-[9px] uppercase tracking-wider bg-indigo-500/10 text-indigo-300 font-bold px-2 py-0.5 rounded border border-indigo-500/20">
                  Data Mining TA
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 line-clamp-1">
                Implementasi Association Rule Mining • 30.000 Transaksi • 78 Aturan Asosiasi
              </p>
            </div>
          </div>

          {/* Tab Button Selector */}
          <nav className="flex items-center bg-zinc-900/80 p-1 rounded-xl border border-zinc-800 w-full sm:w-auto overflow-x-auto backdrop-blur-md">
            <button
              id="tab-toko"
              onClick={() => setActiveTab("toko")}
              className={`flex items-center justify-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs md:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                activeTab === "toko"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              <Library className="h-4 w-4" />
              Situs Toko
            </button>
            <button
              id="tab-keranjang"
              onClick={() => setActiveTab("keranjang")}
              className={`flex items-center justify-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs md:text-sm font-semibold transition-all cursor-pointer relative whitespace-nowrap ${
                activeTab === "keranjang"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              <ShoppingCart className="h-4 w-4" />
              Keranjang
              {totalCartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-indigo-600 text-white rounded-full text-[9px] font-bold h-4.5 w-4.5 flex items-center justify-center animate-bounce border border-zinc-950">
                  {totalCartCount}
                </span>
              )}
            </button>
            <button
              id="tab-rules"
              onClick={() => setActiveTab("rules")}
              className={`flex items-center justify-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs md:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                activeTab === "rules"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              <FileText className="h-4 w-4" />
              Aturan Apriori
            </button>
          </nav>
        </div>
      </header>

      {/* Main Core View Area */}
      <main className="max-w-7xl w-full mx-auto px-4 py-6 flex-grow">
        
        {/* Banner about Association Mining and Thesis metadata */}
        <div className="mb-6 bg-gradient-to-r from-indigo-950/20 via-zinc-900/40 to-zinc-950/60 p-4 rounded-2xl border border-zinc-800 flex items-start gap-3.5 shadow-xl backdrop-blur-md relative overflow-hidden">
          <div className="absolute top-0 right-0 h-24 w-24 bg-indigo-500/5 rounded-full filter blur-xl" />
          <div className="h-9 w-9 md:h-10 md:w-10 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/20 shrink-0">
            <Sparkles className="h-5 w-5 text-indigo-300 animate-pulse" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-indigo-400 tracking-widest bg-indigo-500/10 px-2 py-0.5 rounded-full border border-indigo-500/15">
              Tugas Akhir Data Mining
            </span>
            <h2 className="text-sm md:text-base font-extrabold text-white mt-1.5 leading-tight">
              Sistem E-Commerce Cerdas dengan Pendeteksi Pola Kombinasi Belanja
            </h2>
            <p className="text-xs text-zinc-400 mt-1 max-w-4xl leading-relaxed">
              Model ini menganalisis hubungan asosiasi dari <strong>30.000 transaksi kasir</strong> secara real-time. Setiap kali barang ditambahkan ke keranjang, algoritma akan mencari aturan <strong className="text-indigo-400">If-Buy (Antecedent)</strong> yang cocok untuk memberikan rekomendasi <strong className="text-emerald-400">Recommend (Consequent)</strong> dengan tingkat keyakinan (Confidence/Lift) paling optimal.
            </p>
          </div>
        </div>

        {/* Tab content renderer */}
        <div id="tab-content-panel">
          {activeTab === "toko" && (
            <ProductGrid onAddToCart={handleAddToCart} cartItemsCount={cartItemsCount} />
          )}

          {activeTab === "keranjang" && (
            <CartView
              cart={cart}
              onUpdateQuantity={handleUpdateQuantity}
              onRemoveItem={handleRemoveItem}
              onAddToCart={handleAddToCart}
              onClearCart={handleClearCart}
            />
          )}

          {activeTab === "rules" && <RulesTable />}
        </div>
      </main>

      {/* Footer detailing project credentials */}
      <footer className="border-t border-zinc-900 bg-zinc-950/80 py-6 mt-12 text-center text-xs text-zinc-500 space-y-2">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left space-y-1">
            <p className="font-bold text-zinc-400">Implementasi Tugas Akhir Data Mining - Algoritma Apriori</p>
            <p className="text-[11px] text-zinc-500 font-medium">Menganalisis cross-selling behavior bahan makanan terintegrasi.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-zinc-900/60 px-3 py-1.5 rounded-lg border border-zinc-800 text-[11px] font-mono text-zinc-400">
              <Layers className="h-3.5 w-3.5 text-indigo-400" />
              N_transactions: 30,000
            </div>
            <div className="flex items-center gap-1.5 bg-zinc-900/60 px-3 py-1.5 rounded-lg border border-zinc-800 text-[11px] font-mono text-zinc-400">
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
              Avg Lift: 2.49x
            </div>
          </div>
        </div>
        <p className="text-[10px] text-zinc-600 pt-2 font-medium">
          © 2026 E-Commerce Apriori Recommender. Hak Cipta Dilindungi Undang-Undang.
        </p>
      </footer>

      {/* Toast Alert Indicator */}
      {showToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-indigo-600 text-white font-medium text-xs md:text-sm px-4 py-3 rounded-xl shadow-xl shadow-indigo-600/20 border border-indigo-400/30 flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="h-4 w-4 text-emerald-300" />
          {toastMessage}
        </div>
      )}
    </div>
  );
}
